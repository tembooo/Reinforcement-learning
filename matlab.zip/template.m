
% Run function after implementing all missing pieces and try to find the
% best values for 
% episodes, learning_rate, discount, start_exploration, end_exploration

% [Q, scores] = Q_learning(SnakeGame(), episodes, learning_rate, discount, start_exploration, end_exploration, -10);



function [Q, scores] = Q_learning(game, episodes, learning_rate, discount, start_exploration, end_exploration, render_from_episode)

    Q = zeros(64, 3);

    scores = [];
    epsilons = linspace(start_exploration, end_exploration, episodes);
    for episode = 1:episodes
        epsilon = epsilons(episode);
        game = game.init_game();
        state = game.get_state();
        old_state = state;
        continues = true;
        while(continues)
           
            % Implement Q-learning algorithm
            % You can update the game as follows:
            [game, continues, reward, state] = game.step(action);
            % Where `action` is a number from 1 to 3 specifying the action (1 - turn left, 2 - keep straight, 3 - turn right)
            % `continues` is a boolean specifying if the game continues or is the game over
            % `reward` is a boolean value specifying whether the snake ate the fruit during the last update
            % `state` is a number from 1 to 64 encoding the state that is available to the snake (relative goal and obstacle positions)
            
            scores(end+1) = game.score();
            if episode >= mod(render_from_episode, episodes+1)
                game.render(episode, max(scores));
                pause(1/30)
            end
        end
    end
end

function action = choose_action(Q, state, epsilon)
    
end

function Q = update_Q(Q, old_state, state, action, reward, learning_rate, discount)
    
end