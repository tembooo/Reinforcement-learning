classdef SnakeGame
    %SNAKEGAME Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        grid_sz = [10, 10]
        cell_sz = 5
        snake_color = "#77AC30"
        fruit_color = "r"
        wall_color = "k"
        direction_steps = [-1  0
                            0 -1
                            1  0
                            0  1]
        check_directions = [ 1  1
                             0  1
                            -1  1
                            -1  0
                            -1 -1
                             0 -1
                             1 -1
                             1  0]
        fruit_pos
        snake
    end
    
    methods
        function obj = SnakeGame(grid_sz, cell_sz, snake_color, fruit_color, wall_color)
            %SNAKEGAME Construct an instance of this class
            %   Detailed explanation goes here
            arguments
                grid_sz = [10, 10]
                cell_sz = 5
                snake_color = "#77AC30"
                fruit_color = "r"
                wall_color = "k"
            end
            obj.grid_sz = grid_sz;
            obj.cell_sz = cell_sz;
            obj.snake_color = snake_color;
            obj.fruit_color = fruit_color;
            obj.wall_color = wall_color;
            obj = obj.init_game();
        end
                
        function pos = random_position(self, border_space)
            arguments
                self
                border_space = 1
            end
            pos = [randi([border_space, self.grid_sz(1)-1-border_space]), ...
                randi([border_space, self.grid_sz(2)-1-border_space])];
        end
        function self = spawn_fruit(self, border_space)
            arguments
                self
                border_space = 1
            end
            self.fruit_pos = self.random_position(border_space);
            while(self.snake.check_overlap(self.fruit_pos))
                self.fruit_pos = self.random_position(border_space);
            end
        end

        function self = init_game(self, border_space)
            arguments
                self
                border_space = 1
            end
            self.snake = Snake(self.random_position(border_space));
            self = self.spawn_fruit(border_space);
            % self.fruit_pos = self.snake.pos[0] - np.array([2, 0])
        end
        function self = set_action(self, action)
            self.snake.relative_direction = action - 2;
        end

        function [self, game_continues, reward, state] = step(self, action)
            reward = false;
            game_continues = true;
            self = self.set_action(action);
            if self.snake.relative_direction ~= 0
                self.snake.absolute_direction = mod(self.snake.absolute_direction + self.snake.relative_direction - 1, 4) + 1;
                self.snake.relative_direction = 0;
            end
            last_pos = self.snake.pos(end, :);
    
            for i = self.snake.length()-1:-1:1
                self.snake.pos(i+1, :) = self.snake.pos(i, :);
            end
    
            self.snake.pos(1, :) = self.snake.pos(1, :) + self.direction_steps(self.snake.absolute_direction, :);
    
            if all(self.snake.pos(1, :) == self.fruit_pos)
                self = self.spawn_fruit();
                self.snake.pos(end+1, :) = last_pos;
                reward = true;
            end
            if self.snake.check_overlap(self.snake.pos(1, :), 2)
                game_continues = false;
            end
            if any(self.snake.pos(1, :) == 0) || (self.snake.pos(1, 1) == self.grid_sz(1)-1) || (self.snake.pos(1, 2) == self.grid_sz(1)-1)
                game_continues = false;
            end
            state = self.get_state();
        end

        function obstacle = check_obstacle(self, pos)
            if any(pos == 0) || (pos(1) == self.grid_sz(1)-1) || (pos(2) == self.grid_sz(1)-1)
                obstacle = true;
            else
                obstacle = self.snake.check_overlap(pos, 1);
            end
        end

        function state = get_state(self)
            obstacles = 0;
            goal_dir = min(max(self.fruit_pos - self.snake.pos(1, :), -1), 1);
            for i = 1:8
                test_dir = self.check_directions(1 + mod(i-1+2 * self.snake.absolute_direction, size(self.check_directions, 1)), :);
                if any(i == [2, 4, 6]) && self.check_obstacle(self.snake.pos(1, :) + test_dir)
                    obstacles = obstacles + 2^(i/2 - 1);
                end
                if all(test_dir == goal_dir)
                    goal_state = i;
                end
            end
            state = obstacles * 8 + goal_state;
        end


        function score = score(self)
            score = self.snake.length()-1;
        end

        function f = render(self, episode, high_score)
            arguments
                self
                episode = 1
                high_score = 1
            end
            f = figure(1);
            clf(f);
            ax = axes(f);
            ax.XTick = self.cell_sz * (0:self.grid_sz(1));
            ax.YTick = self.cell_sz * (0:self.grid_sz(2));
            ax.XGrid = 'on';
            ax.YGrid = 'on';
            ax.YDir = 'reverse';
            
            rectangle(ax, 'Position',self.cell_sz*[0, 0, self.grid_sz(1), 1], 'FaceColor', self.wall_color);
            rectangle(ax, 'Position',self.cell_sz*[0, self.grid_sz(2)-1, self.grid_sz(1), 1], 'FaceColor', self.wall_color);
            rectangle(ax, 'Position',self.cell_sz*[self.grid_sz(1)-1, 0, 1, self.grid_sz(2)], 'FaceColor', self.wall_color);
            rectangle(ax, 'Position',self.cell_sz*[0, 0, 1, self.grid_sz(2)], 'FaceColor', self.wall_color);
            
            rectangle(ax, 'Position',self.cell_sz*[self.fruit_pos(1), self.fruit_pos(2), 1, 1], 'FaceColor', self.fruit_color);
            
            for i = 1:self.snake.length()
                rectangle(ax, 'Position',self.cell_sz*[self.snake.pos(i, 1), self.snake.pos(i, 2), 1, 1], 'FaceColor', self.snake_color);
            end
            xlabel(sprintf('Episode: %d\nScore: %d\nHigh score: %d', episode, self.score(), high_score)); 
        end
    end
end

