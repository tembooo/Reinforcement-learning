classdef Snake
    %SNAKE Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        pos
        absolute_direction=1
        relative_direction=0
    end
    
    methods
        function obj = Snake(pos, absolute_direction, relative_direction)
            %SNAKE Construct an instance of this class
            %   Detailed explanation goes here
            arguments
                pos
                absolute_direction=1
                relative_direction=0
            end
            obj = obj.init_state(pos, absolute_direction, relative_direction);
        end
        
        function self = init_state(self, pos, absolute_direction, relative_direction)
            arguments
                self
                pos
                absolute_direction=1
                relative_direction=0
            end
            self.pos = pos;
            self.absolute_direction = absolute_direction;
            self.relative_direction = relative_direction;
        end
    
        function overlap = check_overlap(self, pos, range_start)
            arguments
                self
                pos
                range_start=1
            end
            overlap = false;
            for i = range_start:size(self.pos, 1)
                if all(pos == self.pos(i, :))
                    overlap = true;
                    return
                end
            end
        end

        function len = length(self)
            len = size(self.pos, 1);
        end
    end
end

